
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"   // required for IO_RB4_GetValue(), IO_RC0_SetHigh/Low, IO_RC3_*, etc.

#include <xc.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// Redirect printf() to UART1
void putch(char data)
{
    while (!UART1_IsTxReady());
    UART1_Write((uint8_t)data);
}

int main(void)
{
    SYSTEM_Initialize();
    ADC_Initialize();

    /* ========== HARDWARE CONFIG ========== */
    const float VREF = 5.0f;             // ADC reference
    const float R_FIXED = 10000.0f;      // series resistor ohms
    const uint16_t ADC_MAX = 4095u;      // 12-bit ADC

    /* ========== WATER SAFETY THRESHOLDS (ohms) ==========

         <= 5 k?  => NOT SAFE (contaminated)
         >= 30 k? => SAFE (purer)
       Values between are treated "MAYBE SAFE".
    */
    const float NOT_SAFE_THRESHOLD_LOW = 5000.0f;   // <= 5 k? => NOT SAFE
    const float SAFE_THRESHOLD_HIGH     = 30000.0f; // >= 30 k? => SAFE

    /* Button macro (assume active-low button on RB4). Change if different. */
#define BUTTON_PRESSED()   (!IO_RB4_GetValue())

    bool paused = false;
    bool prev_button_state = BUTTON_PRESSED();



    while (1)
    {
        /* --- Button toggle (with debounce) --- */
        bool cur_button = BUTTON_PRESSED();
        if (cur_button && !prev_button_state)   // detected press
        {
            __delay_ms(40); // debounce
            if (BUTTON_PRESSED())
            {
                paused = !paused;
                __delay_ms(150);
            }
        }
        prev_button_state = cur_button;

        /* If paused: turn RC0 & RC3 off, skip sampling/printing */
        if (paused)
        {
            IO_RC0_SetLow();  // LED off
            IO_RC3_SetLow();  // signal line low while paused
            continue;
        }

        /* === Read ADC and compute water resistance === */
        uint16_t adc = (uint16_t)ADC_ChannelSelectAndConvert(POT);
        float voltage = (adc * VREF) / (float)ADC_MAX;

        float R_water = -1.0f;
        bool valid = true;

        if (adc == 0)
        {
            valid = false; // sensor open / dry
        }
        else if (adc >= ADC_MAX)
        {
            R_water = 0.0f; // short
        }
        else
        {
            R_water = R_FIXED * (voltage / (VREF - voltage));
        }

        /* === Decide state and drive RC0 LED + RC3 signal line ===
           - RC0: LED (on when NOT SAFE)
           - RC3: signal wire for other subsystem (HIGH when NOT SAFE, LOW otherwise)
        */
        const char *state_text;
        if (!valid)
        {
            state_text = "UNKNOWN (sensor dry)";
            IO_RC0_SetLow();
            IO_RC3_SetLow();   // tell other board "not NOT_SAFE" / safe/no-alarm
        }
        else
        {
            if (R_water <= NOT_SAFE_THRESHOLD_LOW)
            {
                state_text = "NOT SAFE";
                IO_RC0_SetHigh(); // local LED ON
                IO_RC3_SetHigh(); // notify other board: NOT SAFE
            }
            else if (R_water >= SAFE_THRESHOLD_HIGH)
            {
                state_text = "SAFE";
                IO_RC0_SetLow();
                IO_RC3_SetLow();
            }
            else
            {
                state_text = "MAYBE SAFE";
                IO_RC0_SetLow();
                IO_RC3_SetLow();
            }
        }

        /* === Print output via UART (unchanged) === */
        if (!valid)
        {
            printf("ADC:%4u  V:%.3f V  Water: >1 M?  State: %s\r\n",
                   adc, voltage, state_text);
        }
        else if (R_water >= 1000000.0f)
        {
            printf("ADC:%4u  V:%.3f V  Water: %.2f M?  State: %s\r\n",
                   adc, voltage, R_water / 1e6f, state_text);
        }
        else if (R_water >= 1000.0f)
        {
            printf("ADC:%4u  V:%.3f V  Water: %.2f k?  State: %s\r\n",
                   adc, voltage, R_water / 1000.0f, state_text);
        }
        else
        {
            printf("ADC:%4u  V:%.3f V  Water: %.2f ?   State: %s\r\n",
                   adc, voltage, R_water, state_text);
        }

        __delay_ms(500);
    }

#undef BUTTON_PRESSED
    return 0;
}
